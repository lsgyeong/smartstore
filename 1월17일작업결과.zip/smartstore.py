import time
import random
import sys
from PyQt5.QtWidgets import *
from PyQt5 import uic
from PyQt5.QtCore import *
import MySQLdb

# 큐 쓰레드 클래스 선언, 큐쓰레드를 쓰려면 QtCore 모듈을 임포트 해야함.
form_class = uic.loadUiType("main.ui")[0]
class Thread(QThread):
    # 초기화 메서드
    def __init__(self, parent): # parent는 Main에서 전달하는 self이다.(Main의 인스턴스)
        super().__init__(parent)
        self.parent = parent # self.parent를 사용하여 Main 위젯을 제어할 수 있다.
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="mealkit")
        self.curs = self.mydb.cursor()
        self.curs.execute("SELECT DISTINCT MEALKIT_NAME from mealkit.recipe")
        result = self.curs.fetchall()
        self.list = []
        if result:
            for i in result:
                self.list.append(i[0])
        self.date = self.parent.str_date
        self.time = self.parent.str_time
        print(self.date)
        print(self.time)
        self.parent.order_comboBox.currentTextChanged.connect(self.go)
        #상품별 판매 금액을 넣어둘 변수
        self.tteokbokki = 0
        self.rozetteokbokki = 0
        self.kimchi = 0
        self.soba = 0
        self.pasta = 0
        self.sondobu = 0
        self.total = 0
        #상품별 판매 개수를 넣어둘 변수
        self.tteokbokki_n = 0
        self.rozetteokbokki_n = 0
        self.kimchi_n = 0
        self.soba_n = 0
        self.pasta_n = 0
        self.sondobu_n = 0
        self.total_n = 0


    def run(self):
        # 쓰레드로 동작시킬 함수 내용 구현
        for i in range(20):
            self.b = random.sample(self.list, 1)
            self.parent.order_comboBox.addItem(self.b[0])
            z = self.parent.order_comboBox.currentText()
            self.curs.execute("SELECT DISTINCT SALES from mealkit.recipe where MEALKIT_NAME = '"+self.parent.order_comboBox.currentText()+"'")
            result = self.curs.fetchall()
            if result:
                for i in result:
                    if self.parent.order_comboBox.currentText() == self.parent.food1.text():
                        self.tteokbokki += int(i[0])
                        self.tteokbokki_n += 1
                        self.parent.price_lineEdit1.setText(str(self.tteokbokki))
                        self.parent.number_lineEdit1.setText(str(self.tteokbokki_n))
                    elif self.parent.order_comboBox.currentText() == self.parent.food2.text():
                        self.rozetteokbokki += int(i[0])
                        self.rozetteokbokki_n += 1
                        self.parent.price_lineEdit2.setText(str(self.rozetteokbokki))
                        self.parent.number_lineEdit2.setText(str(self.rozetteokbokki_n))
                    elif self.parent.order_comboBox.currentText() == self.parent.food3.text():
                        self.kimchi += int(i[0])
                        self.kimchi_n += 1
                        self.parent.price_lineEdit3.setText(str(self.kimchi))
                        self.parent.number_lineEdit3.setText(str(self.kimchi_n))
                    elif self.parent.order_comboBox.currentText() == self.parent.food4.text():
                        self.soba += int(i[0])
                        self.soba_n += 1
                        self.parent.price_lineEdit4.setText(str(self.soba))
                        self.parent.number_lineEdit4.setText(str(self.soba_n))
                    elif self.parent.order_comboBox.currentText() == self.parent.food5.text():
                        self.pasta += int(i[0])
                        self.pasta_n += 1
                        self.parent.price_lineEdit5.setText(str(self.pasta))
                        self.parent.number_lineEdit5.setText(str(self.pasta_n))
                    elif self.parent.order_comboBox.currentText() == self.parent.food6.text():
                        self.sondobu += int(i[0])
                        self.sondobu_n +=1
                        self.parent.price_lineEdit6.setText(str(self.sondobu))
                        self.parent.number_lineEdit6.setText(str(self.sondobu_n))
                    self.total = self.tteokbokki + self.rozetteokbokki + self.kimchi + self.soba +self.pasta + self.sondobu
                    self.total_n = self.tteokbokki_n + self.rozetteokbokki_n + self.kimchi_n + self.soba_n + self.pasta_n + self.sondobu_n
                    self.parent.price_lineEdit7.setText(str(self.total))
                    self.parent.total_number_lineEdit.setText(str(self.total_n))
                    self.parent.order_comboBox.clear()

            time.sleep(1)

    def go(self):
        QMessageBox.information(self.parent,'주문알림',f'{self.b[0]}를 주문했습니다.')



class Main(QMainWindow, form_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.mydb = MySQLdb.connect(host="127.0.0.1", user="root", password="0000", db="mealkit")
        self.curs = self.mydb.cursor()
        self.stackedWidget.setCurrentIndex(0)
        self.menubar.setVisible(False)
        self.manager_login_btn.clicked.connect(self.mainpage)
        self.actionmainpage.triggered.connect(self.mainpage)
        self.manager_signup_btn.clicked.connect(self.signup)
        self.manager_login_singup_btn.clicked.connect(self.login)
        self.actionlogout.triggered.connect(self.login)
        self.product_registration_btn.clicked.connect(self.product)
        self.actionproduct.triggered.connect(self.product)
        self.recipe_management_go_btn.clicked.connect(self.recipe)
        self.recipe_management_btn.clicked.connect(self.recipe)
        self.actionreceipe.triggered.connect(self.recipe)
        self.order_management_btn.clicked.connect(self.order)
        self.actionorder.triggered.connect(self.order)
        self.inventory_management_btn.clicked.connect(self.inventory)
        self.actioninventory.triggered.connect(self.inventory)
        self.inventory_lookup_btn.clicked.connect(self.inventory)

        # 위에까지는 각 페이지 별 시그널 연결

        self.timer = QTimer(self) # 윈도우가 생성될 때 QTimer 객체 생성해야함
        self.timer.start(1000) # 생성한 객체에 interval(1초) 추가 설정
        self.timer.timeout.connect(self.timeout)

        #  버튼에 쓰레드 연결
        self.order_lookup_btn.clicked.connect(self.threadAction)

    def inventory(self):
        self.stackedWidget.setCurrentIndex(5)

    def order(self):
        self.stackedWidget.setCurrentIndex(4)

    def recipe(self):
        self.stackedWidget.setCurrentIndex(6)

    def signup(self):
        self.stackedWidget.setCurrentIndex(1)

    def login(self):
        self.stackedWidget.setCurrentIndex(0)

    def mainpage(self):
        self.stackedWidget.setCurrentIndex(2)
        self.menubar.setVisible(True)

    def product(self):
        self.stackedWidget.setCurrentIndex(3)

    def timeout(self):
        self.cur_date = QDate.currentDate()
        self.str_date = self.cur_date.toString(Qt.ISODate)
        self.cur_time = QTime.currentTime()
        self.str_time = self.cur_time.toString("hh:mm:ss")
        self.statusBar().showMessage(f'현재 날짜:{self.str_date}, 현재 시간: {self.str_time}')

    # 주문 버튼을 눌렀을 때 실행 될 메서드
    def threadAction(self):
        x = Thread(self) # self 는 Main의 인스턴스, Thread 클래스에서 parent로 전달
        x.start()



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Main()
    window.show()
    app.exec_()